class Todo {
  final String task;
  final DateTime createdAt;

  Todo({
    required this.task,
    required this.createdAt,
  });
}
